package com.cg.hotelbooking.services;
import java.util.ArrayList;
import java.util.List;
import com.cg.hotelbooking.beans.Customer;
import com.cg.hotelbooking.beans.Rooms;
import com.cg.hotelbooking.daoservices.CustomerDAO;
import com.cg.hotelbooking.daoservices.CustomerDAOImpl;
import com.cg.hotelbooking.exceptions.NoSuchCustomerFoundException;
import com.cg.hotelbooking.exceptions.RoomNotAvailableException;
public class CustomerServicesImpl implements CustomerServices{
	CustomerDAOImpl customerDao = new CustomerDAOImpl();
	Customer customer = new Customer();
	@Override
	public Customer acceptCustomerDetails(String customerUserName, String customerName, String emailId, long phoneNo,
			Rooms rooms, double noOfDays, int noOfPeople) {

		System.out.println(rooms);
		Customer customer=customerDao.save(new Customer(customerUserName, customerName, emailId, phoneNo,rooms, noOfDays, noOfPeople));
		System.out.println(customer);
		return customer;
	}
	@Override
	public List<Customer> getAllCustomerDetails() {		
		return customerDao.findAll();
	}
	@Override
	public Customer getCustomerDetails(int customerId) throws NoSuchCustomerFoundException {
		Customer customers = customerDao.findOne(customerId);
		if(customers==null)
			throw new NoSuchCustomerFoundException(); 
		return customers;
	}
	@Override
	public double calculateRoomTariff(int noOfDays,int noOfPeople,int customerId) throws RoomNotAvailableException {
		Customer cust = customerDao.findOne(customerId);
		System.out.println(cust.getRooms());
		if(Rooms.AC ==cust.getRooms()) {
			return (1.18* (2500*noOfDays*noOfPeople));
		}			
		else
			return (1.18* (2000*noOfDays*noOfPeople));			
	}

	

	




	

}
