package com.cg.hotelbooking.services;
import java.util.List;


import com.cg.hotelbooking.beans.Customer;

import com.cg.hotelbooking.beans.Rooms;
import com.cg.hotelbooking.exceptions.NoSuchCustomerFoundException;
import com.cg.hotelbooking.exceptions.RoomNotAvailableException;


public interface CustomerServices {
		Customer acceptCustomerDetails(String customerUserName, String customerName, String emailId, long phoneNo,  Rooms rooms, double noOfDays);
		
		List<Customer> getAllCustomerDetails();


		Customer getCustomerDetails(int customerId) throws NoSuchCustomerFoundException;
		double calculateRoomTariff(int noOfDays) throws RoomNotAvailableException;
		
}
