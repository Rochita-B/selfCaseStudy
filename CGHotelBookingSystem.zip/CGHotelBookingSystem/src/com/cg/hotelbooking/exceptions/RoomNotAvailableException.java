package com.cg.hotelbooking.exceptions;

public class RoomNotAvailableException extends Exception{

	public RoomNotAvailableException() {
		super();
		System.out.println("sorry! No rroms available");
	}

	public RoomNotAvailableException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public RoomNotAvailableException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public RoomNotAvailableException(String arg0) {
		super(arg0);
	}

	public RoomNotAvailableException(Throwable arg0) {
		super(arg0);
	}

}
