package com.cg.hotelbooking.client;

import java.util.Scanner;

import com.cg.hotelbooking.beans.Customer;
import com.cg.hotelbooking.beans.Rooms;
import com.cg.hotelbooking.services.CustomerServices;
import com.cg.hotelbooking.services.CustomerServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		CustomerServices services=new CustomerServicesImpl();
		System.out.println("welcome to Rochita's Royal");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer's Details....................");
		System.out.println("\n Enter Name: ");
		String customerName = sc.nextLine();
		System.out.println("\nEnter UserName:");
		String customerUserName=sc.nextLine();
		System.out.println("\nEnter Email Id: ");
		String emailId = sc.nextLine();
		System.out.println("\nEnter Phone Number:");
		long phoneNo = sc.nextLong();
		System.out.println("\nEnter the Number of Days:");
		double noOfDays = sc.nextDouble();
		System.out.println("\n...............TYPES OF ROOMS.................\n1.AC\n2.Non AC");
		System.out.println("\nEnter what kind of room is needed:");
		Rooms rooms=null;
		int ch=sc.nextInt();
		switch(ch) {
		case 1: rooms = Rooms.AC;break;
		case 2: rooms = Rooms.Non_AC;break;
		default: System.out.println("Invalid Choice");break;
		}
		
		Customer customer1 = services.acceptCustomerDetails(customerUserName, customerName, emailId, phoneNo, rooms, noOfDays);
		
	
		
		

		
		
		
		
		
		
	}

}
