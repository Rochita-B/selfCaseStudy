package com.cg.hotelbooking.beans;
public class Customer {
	private int customerId;
	private String customerUserName;
	private String customerName;
	private String emailId;
	private long phoneNo;
	private double noOfDays;
	private Rooms rooms;
	public Customer() {
		super();
	}
	
	public Customer(int customerId) {
		super();
		this.customerId = customerId;
	}

	public Customer(int customerId, String customerUserName, String customerName, String emailId, long phoneNo,
			double noOfDays, Rooms rooms) {
		super();
		this.customerId = customerId;
		this.customerUserName = customerUserName;
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.noOfDays = noOfDays;
		this.rooms = rooms;
	}
	public Customer(String customerUserName, String customerName, String emailId, long phoneNo, double noOfDays,
			Rooms rooms) {
		super();
		this.customerUserName = customerUserName;
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.noOfDays = noOfDays;
		this.rooms = rooms;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerUserName() {
		return customerUserName;
	}
	public void setCustomerUserName(String customerUserName) {
		this.customerUserName = customerUserName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public double getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(double noOfDays) {
		this.noOfDays = noOfDays;
	}
	public Rooms getRooms() {
		return rooms;
	}
	public void setRooms(Rooms rooms) {
		this.rooms = rooms;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerId;
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + ((customerUserName == null) ? 0 : customerUserName.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		long temp;
		temp = Double.doubleToLongBits(noOfDays);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (int) (phoneNo ^ (phoneNo >>> 32));
		result = prime * result + ((rooms == null) ? 0 : rooms.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerId != other.customerId)
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (customerUserName == null) {
			if (other.customerUserName != null)
				return false;
		} else if (!customerUserName.equals(other.customerUserName))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (Double.doubleToLongBits(noOfDays) != Double.doubleToLongBits(other.noOfDays))
			return false;
		if (phoneNo != other.phoneNo)
			return false;
		if (rooms != other.rooms)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerUserName=" + customerUserName + ", customerName="
				+ customerName + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", noOfDays=" + noOfDays + ", rooms="
				+ rooms + "]";
	}
	
	
	
}	