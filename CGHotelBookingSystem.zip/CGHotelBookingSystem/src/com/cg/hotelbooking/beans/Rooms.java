package com.cg.hotelbooking.beans;

public enum Rooms {
	AC, Non_AC;
}
