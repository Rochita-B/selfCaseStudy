package com.cg.hotelbooking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.hotelbooking.beans.Customer;
import com.cg.hotelbooking.beans.Rooms;
import com.cg.hotelbooking.exceptions.NoSuchCustomerFoundException;
import com.cg.hotelbooking.exceptions.RoomNotAvailableException;
import com.cg.hotelbooking.services.CustomerServices;
import com.cg.hotelbooking.services.CustomerServicesImpl;
import com.cg.hotelbooking.util.HotelManagerDBUtil;

public class TestClass {
	private static CustomerServices cust;

	@BeforeClass
	public static void setUpTestEnv() {
		cust = new CustomerServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Customer customer1=new Customer(101, "rochitab", "rochita bagchi", "rochita@gmail.com", 80176, 2, Rooms.AC);
		HotelManagerDBUtil.customerDetails.put(customer1.getCustomerId(), customer1);
	}
	@Test(expected=NoSuchCustomerFoundException.class)
	public void testGetCustomerDetailsForInvalidCustomerId() throws NoSuchCustomerFoundException{
		cust.getCustomerDetails(125);
	}
	@Test
	public void testGetCustomerDetailsForValidCustomerId() throws NoSuchCustomerFoundException {
		Customer expectedValue=new Customer(101);
		Customer actualValue=cust.getCustomerDetails(101);
		Assert.assertEquals(expectedValue,actualValue);
	}
	@Test
	public void testGetCustomerDetailsForInvalidRoomChoice() throws RoomNotAvailableException{
		cust.getAllCustomerDetails();
	}
	@Test
	public void testGetCustomerDetailsForValidRoomChoice() throws RoomNotAvailableException, NoSuchCustomerFoundException{
		Customer expectedValue=new Customer(101,"rochitab", "rochita", "rochita@gmail.com", 80176, 2, Rooms.AC);
		Customer actualValue=cust.getCustomerDetails(101);
		Assert.assertEquals(expectedValue,actualValue);
	}
	@After
	public void tearDownTestData() {
		HotelManagerDBUtil.customerDetails.clear();
		HotelManagerDBUtil.CUSTOMER_ID_COUNTER = 100;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		cust = null;
	}
}
