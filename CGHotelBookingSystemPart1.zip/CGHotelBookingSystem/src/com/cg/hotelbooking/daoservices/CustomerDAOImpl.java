package com.cg.hotelbooking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.hotelbooking.beans.Customer;
import com.cg.hotelbooking.util.HotelManagerDBUtil;
public class CustomerDAOImpl implements CustomerDAO{

	@Override
	public Customer save(Customer customer) {
		customer.setCustomerId(HotelManagerDBUtil.getCUSTOMER_ID_COUNTER());
		HotelManagerDBUtil.customerDetails.put(customer.getCustomerId(), customer);
		return customer;		
	}

	@Override
	public boolean update(Customer customer) {
		return false;
	}

	@Override
	public Customer findOne(int customerId) {
		return HotelManagerDBUtil.customerDetails.get(customerId);

	}

	@Override
	public List<Customer> findAll() {
		return new ArrayList<> (HotelManagerDBUtil.customerDetails.values());	}

}
