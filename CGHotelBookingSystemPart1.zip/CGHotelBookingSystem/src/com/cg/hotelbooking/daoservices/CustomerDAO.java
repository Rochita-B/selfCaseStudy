package com.cg.hotelbooking.daoservices;
import java.util.List;
import com.cg.hotelbooking.beans.Customer;
public interface CustomerDAO {
	Customer save(Customer customer); 
	boolean update( Customer customer);
	Customer findOne(int  customerId);
	List<Customer> findAll();
}
