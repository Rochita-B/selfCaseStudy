package com.cg.hotelbooking.services;

import java.util.List;

import com.cg.hotelbooking.beans.BillingDetails;
import com.cg.hotelbooking.beans.Customer;
import com.cg.hotelbooking.beans.Date;
import com.cg.hotelbooking.beans.Rooms;
import com.cg.hotelbooking.daoservices.CustomerDAO;
import com.cg.hotelbooking.daoservices.CustomerDAOImpl;


public class CustomerServicesImpl implements CustomerServices{
	private  CustomerDAO customerDAO=new CustomerDAOImpl();


	@Override
	public int acceptCustomerDetails(int customerId, String customerName, String emailId, long phoneNo,
			BillingDetails billingDetails, Date date, Rooms rooms) {
		Customer customer=new Customer(customerId, customerName, emailId, phoneNo);
		customer=customerDAO.save(customer);
		return customer.getCustomerId();
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int acceptCustomerDetails(int customerId, String customerName, String emailId, long phoneNo,
			BillingDetails billingDetails, Date date, Rooms rooms, int amount) {
		// TODO Auto-generated method stub
		return 0;
	}

}
