package com.cg.hotelbooking.services;
import java.util.List;

import com.cg.hotelbooking.beans.BillingDetails;
import com.cg.hotelbooking.beans.Customer;
import com.cg.hotelbooking.beans.Date;
import com.cg.hotelbooking.beans.Rooms;


public interface CustomerServices {
		int acceptCustomerDetails(int customerId, String customerName, String emailId, long phoneNo, BillingDetails billingDetails,
			Date date, Rooms rooms);
		
		List<Customer> getAllCustomerDetails();

		int acceptCustomerDetails(int customerId, String customerName, String emailId, long phoneNo,
				BillingDetails billingDetails, Date date, Rooms rooms, int amount);

		
}
