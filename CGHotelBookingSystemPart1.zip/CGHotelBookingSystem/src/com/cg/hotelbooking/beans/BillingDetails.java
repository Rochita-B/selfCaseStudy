package com.cg.hotelbooking.beans;

public class BillingDetails {
	private int amount;
	private int cGst;
	private int sgst;

	public BillingDetails() {
		super();
	}
	public BillingDetails(int amount, int cGst, int sgst) {
		super();
		this.amount = amount;
		this.cGst = cGst;
		this.sgst = sgst;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getcGst() {
		return cGst;
	}
	public void setcGst(int cGst) {
		this.cGst = cGst;
	}
	public int getSgst() {
		return sgst;
	}
	public void setSgst(int sgst) {
		this.sgst = sgst;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amount;
		result = prime * result + cGst;
		result = prime * result + sgst;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BillingDetails other = (BillingDetails) obj;
		if (amount != other.amount)
			return false;
		if (cGst != other.cGst)
			return false;
		if (sgst != other.sgst)
			return false;
		return true;
	}

}
