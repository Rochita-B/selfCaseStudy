package com.cg.hotelbooking.beans;

public class Date {
	Date checkinDay;
	Date checkoutDay;
	public Date() {
		super();
	}
	public Date(Date checkinDay, Date checkoutDay) {
		super();
		this.checkinDay = checkinDay;
		this.checkoutDay = checkoutDay;
	}
	public Date getCheckinDay() {
		return checkinDay;
	}
	public void setCheckinDay(Date checkinDay) {
		this.checkinDay = checkinDay;
	}
	public Date getCheckoutDay() {
		return checkoutDay;
	}
	public void setCheckoutDay(Date checkoutDay) {
		this.checkoutDay = checkoutDay;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Date other = (Date) obj;
		if (checkinDay != other.checkinDay) {
			return false;
		}
		if (checkoutDay != other.checkoutDay) {
			return false;
		}
		return true;
	}
}
