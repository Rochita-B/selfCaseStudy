package com.cg.hotelbooking.beans;

public enum Rooms {
	AC_TWO_BED, AC_THREE_BED, NONAC_TWO_BED,NONAC_THREE_BED;
}
