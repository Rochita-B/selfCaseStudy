package com.cg.hotelbooking.client;

public class MainClass {

	public static void main(String[] args) {
		
	}

}
