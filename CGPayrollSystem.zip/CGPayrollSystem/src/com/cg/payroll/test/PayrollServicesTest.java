package com.cg.payroll.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class PayrollServicesTest {
	/*private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new PayrollServicesImpl();
	}
	@Before
	public void setUpTestData(){
		Associate associate1 = new Associate(101,"Rochita", "Bagchi","rochita@gmail.com","Analyst","abc1234","biki@gmail.com",
				new Salary(400000,12000,12000), 
				new BankDetails(100050,"citi bank","cit123456"));
		Associate associate2=new Associate(102,"Haya", "Fatima","hayafatima@gmail.com","Student","Analyst","abc1234",
				new Salary(400000,12000,12000), new BankDetails(100050,"icici bank","AXIS00003"));
		PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
		PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		services.getAssociateDetails(1012);
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId() /*throws AssociateDetailsNotFoundException*/ /*{
		Associate expectedAssociate=new Associate(101,"Rochita", "Bagchi", "Student","Analyst","abc1235","rochita@gmail.com",
				new Salary(450000,12000,12000), 
				new BankDetails(100050,"axis bank", "AXIS00002"));
		Associate actualAssociate =null;*/
		/*try {
			actualAssociate = services.getAssociateDetails(101);
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		Assert.assertEquals(expectedAssociate, actualAssociate);*/
	//}
	/*@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedId=101;
		int actualId=services.acceptAssociateDetails(101,"Rochita", "Bagchi", "Student","Analyst","abc1234","rochita@gmail.com", 
				10000,400000,12000,12000,100050,
				"axis bank", "AXIS00002");

	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		services.calculateNetSalary(1023);
	}


	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException {
		//Associate associate2=new Associate(102,"Haya", "Fatima","hayafatima@gmail.com","Student","Analyst","abc1234",
		//new Salary(470000,12500,15000), new BankDetails(100050,"icici bank","AXIS00003"));
		double expectedNetSalary=433400.0;
		double actualNetSalary=services.calculateNetSalary(101);
		System.out.println(actualNetSalary);
		Assert.assertEquals(expectedNetSalary, actualNetSalary,0);
	}

	@Test
	public void testGetAllAssociateDetails() {
		Associate associate1 = new Associate(101,"Rishita", "Bagchi", "Student","Analyst","abc2554","rishita@gmail.com",
				new Salary(450000,12000,12000), new BankDetails(100050,
						"axis bank", "AXIS00002"));
		Associate associate2=new Associate(102,"Rochita", "Bagchi", "Student","Analyst","abc1234","rochita@gmail.com",
				new Salary(10000,400000,12000,12000,100050, 0), new BankDetails("axis bank", "AXIS00002"));
		ArrayList<Associate> expectedAssociateList=new ArrayList<>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		ArrayList<Associate>actualAssociates=(ArrayList<Associate>)services.getAllAssociatesDetails();
		Assert.assertEquals(expectedAssociateList, expectedAssociateList);
	}

	@After
	public void tearDownTestDate() {
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}*/

}