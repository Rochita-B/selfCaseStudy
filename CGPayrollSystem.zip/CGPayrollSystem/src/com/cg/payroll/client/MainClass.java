package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class MainClass 
{

	public static void main(String[] args)  {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails(1,10000, "Rochita","Bagchi","rochita@gmail.com","Student","Analyst","abc1235",
				450000,12000,12000,
				100050,"axis bank", "AXIS00002");
		/*int associateId1=services.acceptAssociateDetails(102,"Haya", "Fatima","hayafatima@gmail.com","Student","Analyst","abc1234",10000,
				470000,12500,15000,
				100050,"icici bank","AXIS00003");*/
		
		System.out.println("Associate Details: "+associateId);
	//	System.out.println("Associate Details: "+associateId1);
		
		/* Associate associate = null;
		try {
			associate = services.getAssociateDetails(associateId);
			System.out.println("\nDetails of AssociateId: "+associateId);
			System.out.println("Annual Net Salary:"+services.calculateNetSalary(associateId));
			System.out.println("Monthly Net Salary: "+(services.calculateNetSalary(associateId))/12);
			System.out.println("Annual Gross salary:"+services.calculateGrossSalary(associateId));
					
		}catch(AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			associate = services.getAssociateDetails(associateId1);
			System.out.println("\nDetails of AssociateId: "+associateId1);
			System.out.println("Annual Net Salary:"+services.calculateNetSalary(associateId1));
			System.out.println("Monthly Net Salary: "+(services.calculateNetSalary(associateId1))/12);
			System.out.println("Annual Gross salary:"+services.calculateGrossSalary(associateId1));
					
		}catch(AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}*/
	}
}


