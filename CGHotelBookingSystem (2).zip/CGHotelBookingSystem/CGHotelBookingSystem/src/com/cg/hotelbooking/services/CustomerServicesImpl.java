package com.cg.hotelbooking.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.hotelbooking.beans.Customer;

import com.cg.hotelbooking.beans.Rooms;
import com.cg.hotelbooking.daoservices.CustomerDAO;
import com.cg.hotelbooking.daoservices.CustomerDAOImpl;
import com.cg.hotelbooking.exceptions.NoSuchCustomerFoundException;
import com.cg.hotelbooking.exceptions.RoomNotAvailableException;


public class CustomerServicesImpl implements CustomerServices{
	CustomerDAOImpl customerDao = new CustomerDAOImpl();
	Customer customer = new Customer();

	@Override
	public Customer acceptCustomerDetails(String customerUserName, String customerName, String emailId, long phoneNo,
			Rooms rooms, double noOfDays) {

		Customer customer=customerDao.save(new Customer(customerUserName, customerName, emailId, phoneNo, noOfDays, rooms));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		ArrayList<Customer> customers = (ArrayList<Customer>) customerDao.findAll();		
		return (ArrayList<Customer>) customers;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws NoSuchCustomerFoundException {
		Customer customers = customerDao.findOne(customerId);
		if(customers==null)
			throw new NoSuchCustomerFoundException(); 
		return customers;
	}

	@Override
	public double calculateRoomTariff(int noOfDays,int noOfPeople) throws RoomNotAvailableException {
		Customer cust = new Customer(customer.getCustomerId());
		if(Rooms.AC.equals(cust.getRooms()))
			return ((0.18 * 2500) * noOfDays) + (2500*noOfDays);
		else
			return ((0.18*2000)*noOfDays)+(2000*noOfDays);
	}

	

	




	

}
