package com.cg.hotelbooking.beans;
public class Customer {
	private int customerId;
	private String customerUserName;
	private String customerName;
	private String emailId;
	private long phoneNo;
	private double noOfDays;
	private Rooms rooms;
	private int noOfPeople;
	public Customer() {
		super();
	}
	
	public Customer(int customerId) {
		super();
		this.customerId = customerId;
	}

	public Customer(int customerId, String customerUserName, String customerName, String emailId, long phoneNo,
			double noOfDays, Rooms rooms) {
		super();
		this.customerId = customerId;
		this.customerUserName = customerUserName;
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.noOfDays = noOfDays;
		this.rooms = rooms;
	}
	public Customer(String customerUserName, String customerName, String emailId, long phoneNo, double noOfDays,
			Rooms rooms) {
		super();
		this.customerUserName = customerUserName;
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.noOfDays = noOfDays;
		this.rooms = rooms;
	}
	
	public Customer(int customerId, String customerUserName, String customerName, String emailId, long phoneNo,
			double noOfDays, int noOfPeople) {
		super();
		this.customerId = customerId;
		this.customerUserName = customerUserName;
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.noOfDays = noOfDays;
		this.noOfPeople = noOfPeople;
	}

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerUserName() {
		return customerUserName;
	}
	public void setCustomerUserName(String customerUserName) {
		this.customerUserName = customerUserName;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public double getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(double noOfDays) {
		this.noOfDays = noOfDays;
	}
	public Rooms getRooms() {
		return rooms;
	}
	public void setRooms(Rooms rooms) {
		this.rooms = rooms;
	}
	public int getNoOfPeople() {
		return noOfPeople;
	}

	public void setNoOfPeople(int noOfPeople) {
		this.noOfPeople = noOfPeople;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + noOfPeople;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Customer other = (Customer) obj;
		if (noOfPeople != other.noOfPeople) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerUserName=" + customerUserName + ", customerName="
				+ customerName + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", noOfDays=" + noOfDays + ", rooms="
				+ rooms + ", noOfPeople=" + noOfPeople + "]";
	}
	
	
	
	
}	