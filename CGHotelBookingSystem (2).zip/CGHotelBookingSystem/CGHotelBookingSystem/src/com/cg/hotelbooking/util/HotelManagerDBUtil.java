package com.cg.hotelbooking.util;

import java.util.HashMap;

import com.cg.hotelbooking.beans.Customer;

public class HotelManagerDBUtil {
	public static  HashMap<Integer, Customer> customerDetails = new HashMap<>();
	public static int CUSTOMER_ID_COUNTER = 100;
	public static int getCUSTOMER_ID_COUNTER() {
		return ++CUSTOMER_ID_COUNTER;
	}
	
}
